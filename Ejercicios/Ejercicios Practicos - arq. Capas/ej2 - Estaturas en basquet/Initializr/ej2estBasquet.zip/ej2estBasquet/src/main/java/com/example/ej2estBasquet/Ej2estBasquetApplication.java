package com.example.ej2estBasquet;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ej2estBasquetApplication {

	public static void main(String[] args) {
		SpringApplication.run(Ej2estBasquetApplication.class, args);
	}

}
