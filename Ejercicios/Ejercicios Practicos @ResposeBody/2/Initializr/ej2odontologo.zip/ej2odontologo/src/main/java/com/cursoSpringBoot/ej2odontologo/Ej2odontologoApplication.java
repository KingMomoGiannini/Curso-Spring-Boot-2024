package com.cursoSpringBoot.ej2odontologo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ej2odontologoApplication {

	public static void main(String[] args) {
		SpringApplication.run(Ej2odontologoApplication.class, args);
	}

}
