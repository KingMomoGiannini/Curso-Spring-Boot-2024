package com.example.ej1PromNotas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ej1PromNotasApplicationTests {

	@Test
	void contextLoads() {
	}

}
