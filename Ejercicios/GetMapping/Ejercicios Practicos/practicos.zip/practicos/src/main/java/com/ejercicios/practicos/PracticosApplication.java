package com.ejercicios.practicos;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PracticosApplication {

	public static void main(String[] args) {
		SpringApplication.run(PracticosApplication.class, args);
	}

}
