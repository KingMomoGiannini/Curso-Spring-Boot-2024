package com.ejercicios.hellobye;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HellobyeApplication {

	public static void main(String[] args) {
		SpringApplication.run(HellobyeApplication.class, args);
	}

}
