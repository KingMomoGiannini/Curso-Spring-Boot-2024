package com.example.ej1PromNotas;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ej1PromNotasApplication {

	public static void main(String[] args) {
		SpringApplication.run(Ej1PromNotasApplication.class, args);
	}

}
