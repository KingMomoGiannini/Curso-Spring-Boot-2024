package com.example.ej2estBasquet;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ej2estBasquetApplicationTests {

	@Test
	void contextLoads() {
	}

}
