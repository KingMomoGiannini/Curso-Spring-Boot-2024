package com.ejercicios.altapersonas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AltapersonasApplicationTests {

	@Test
	void contextLoads() {
	}

}
