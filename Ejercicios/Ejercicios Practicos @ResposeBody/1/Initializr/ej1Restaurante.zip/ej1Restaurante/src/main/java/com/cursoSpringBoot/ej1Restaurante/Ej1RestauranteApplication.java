package com.cursoSpringBoot.ej1Restaurante;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ej1RestauranteApplication {

	public static void main(String[] args) {
		SpringApplication.run(Ej1RestauranteApplication.class, args);
	}

}
