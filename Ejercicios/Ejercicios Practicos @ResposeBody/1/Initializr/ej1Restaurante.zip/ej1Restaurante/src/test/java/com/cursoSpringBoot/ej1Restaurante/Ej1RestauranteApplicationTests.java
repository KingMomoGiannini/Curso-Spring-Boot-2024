package com.cursoSpringBoot.ej1Restaurante;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ej1RestauranteApplicationTests {

	@Test
	void contextLoads() {
	}

}
