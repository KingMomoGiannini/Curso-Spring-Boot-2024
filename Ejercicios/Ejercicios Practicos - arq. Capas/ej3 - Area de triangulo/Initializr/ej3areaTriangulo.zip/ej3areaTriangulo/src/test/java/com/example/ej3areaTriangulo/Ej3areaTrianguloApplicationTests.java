package com.example.ej3areaTriangulo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ej3areaTrianguloApplicationTests {

	@Test
	void contextLoads() {
	}

}
