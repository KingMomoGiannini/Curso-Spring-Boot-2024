package com.curso.proyectofinal;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BazarApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
