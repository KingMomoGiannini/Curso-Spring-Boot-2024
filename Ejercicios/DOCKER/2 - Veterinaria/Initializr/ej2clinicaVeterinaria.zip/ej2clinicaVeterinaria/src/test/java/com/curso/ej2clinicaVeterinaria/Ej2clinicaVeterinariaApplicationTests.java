package com.curso.ej2clinicaVeterinaria;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ej2clinicaVeterinariaApplicationTests {

	@Test
	void contextLoads() {
	}

}
