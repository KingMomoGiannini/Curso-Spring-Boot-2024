package com.todocodeacademy;

public class InyeccionDeDependencias {

    public static void main(String[] args) {
       
    }
    
}
